package com.auca.library.service;

import com.auca.library.domain.Location;
import com.auca.library.enums.LocationType;
import com.auca.library.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.UUID;

public class LocationService {

    public Location createLocation(Location location, UUID parentId) {
        if (location.getLocationType() != LocationType.PROVINCE && parentId == null) {
            throw new IllegalArgumentException("Non-province locations must have a valid parent ID.");
        }

        if (parentId != null) {
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Location parent = session.get(Location.class, parentId);
                if (parent == null) {
                    throw new IllegalArgumentException("Parent location does not exist.");
                }
                location.setParentId(parentId);
            }
        }

        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(location);
            transaction.commit();
            return location;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw new RuntimeException(e);
        }
    }
}